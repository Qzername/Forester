set shell = createobject ("wscript.shell")

strtext = inputbox ("Jaka wiadomosc spamic?")
strtimes = inputbox ("Ile razy mam spamic?")
strspeed = inputbox ("Jak szybko mam spamic? (1000 - co jedna sekunde, 500 - pol sekundy itd.)")
strtimeneed = inputbox ("Ile sekund potrzebujesz aby wejsc w chat?")
If not isnumeric (strtimes & strspeed & strtimeneed) then
msgbox "Cos zle podales"
wscript.quit
End If
strtimeneed2 = strtimeneed * 1000
do
msgbox "Masz " & strtimeneed & " sekund aby wejść do chatu"
wscript.sleep strtimeneed2
for i=0 to strtimes
shell.sendkeys (strtext & "{enter}" & "{enter}")
wscript.sleep strspeed
Next
wscript.sleep strspeed * strtimes / 10
returnvalue=MsgBox ("Chcesz jeszcze raz zaspamic?",36)
If returnvalue=6 Then
Msgbox "Ok, Spambox znowu sie wlaczy"
End If
If returnvalue=7 Then
msgbox "Spambox zostal wylaczony"
wscript.quit
End IF
loop